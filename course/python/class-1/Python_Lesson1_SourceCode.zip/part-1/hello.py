#!/usr/bin/python

print ("Hello, Python!")